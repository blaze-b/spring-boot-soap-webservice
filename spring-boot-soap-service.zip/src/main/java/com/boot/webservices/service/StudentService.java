package com.boot.webservices.service;


import com.boot.webservices.model.Students;


public interface StudentService {
	public Students findStudent(String name);
}
